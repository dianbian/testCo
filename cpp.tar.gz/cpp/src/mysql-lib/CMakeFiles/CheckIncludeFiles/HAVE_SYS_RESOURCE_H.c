/* */
#include <sys/resource.h>


int main(void){return 0;}

