/* */
#include <vis.h>


int main(void){return 0;}

