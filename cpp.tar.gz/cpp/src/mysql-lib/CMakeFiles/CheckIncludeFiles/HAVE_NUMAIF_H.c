/* */
#include <numaif.h>


int main(void){return 0;}

