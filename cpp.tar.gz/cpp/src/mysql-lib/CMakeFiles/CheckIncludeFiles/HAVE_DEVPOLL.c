/* */
#include <sys/devpoll.h>


int main(void){return 0;}

