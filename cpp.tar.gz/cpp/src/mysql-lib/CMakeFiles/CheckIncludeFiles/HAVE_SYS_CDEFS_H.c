/* */
#include <sys/cdefs.h>


int main(void){return 0;}

