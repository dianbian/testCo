/* */
#include <curses.h>
#include <term.h>


int main(void){return 0;}

