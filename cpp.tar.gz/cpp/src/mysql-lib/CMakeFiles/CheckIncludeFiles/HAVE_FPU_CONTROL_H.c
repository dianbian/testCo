/* */
#include <fpu_control.h>


int main(void){return 0;}

