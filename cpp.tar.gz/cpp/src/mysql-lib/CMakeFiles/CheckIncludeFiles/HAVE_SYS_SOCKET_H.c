/* */
#include <sys/socket.h>


int main(void){return 0;}

