/* */
#include <sys/epoll.h>


int main(void){return 0;}

