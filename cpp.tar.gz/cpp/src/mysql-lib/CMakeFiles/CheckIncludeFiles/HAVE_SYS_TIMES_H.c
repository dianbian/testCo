/* */
#include <sys/times.h>


int main(void){return 0;}

