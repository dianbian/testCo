/* */
#include <fnmatch.h>


int main(void){return 0;}

