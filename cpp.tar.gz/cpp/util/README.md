This project is the Tars base tool library.
